-- DROP SCHEMA producaobd;

drop table Lote

-- Criando o banco de dados PRODUCAOBD.
CREATE DATABASE producaobd;

use producaobd

-- Criando a tabela FABRICANTE.
CREATE TABLE  Fabricante (
codfabricante SMALLINT NOT NULL,
nomefabricante VARCHAR(30) NOT NULL,
PRIMARY KEY (codfabricante));

-- Criando a tabela PRODUTO.
CREATE TABLE  Produto (
codproduto INT NOT NULL,
nomeproduto VARCHAR(30) NOT NULL,
codfabricante SMALLINT NOT NULL,
PRIMARY KEY (codproduto),
CONSTRAINT fk_Produto_Fabricante
FOREIGN KEY (codfabricante)
REFERENCES Fabricante (codfabricante));

-- Criando a tabela LOTE.
CREATE TABLE Lote (
numlote INT NOT NULL,
datavalidade DATE NOT NULL,
precounitario DECIMAL(10,2),
quantidade SMALLINT NOT NULL DEFAULT 100,
valorlote DECIMAL(10,2),
codproduto INT NOT NULL,
PRIMARY KEY (numlote),
CONSTRAINT fk_Lote_Produto
FOREIGN KEY (codproduto)
REFERENCES Produto (codproduto));

-- Inserindo registros na tabela FABRICANTE.

INSERT INTO Fabricante VALUES (1, 'Clear');
INSERT INTO Fabricante VALUES (2, 'Rexona');
INSERT INTO Fabricante VALUES (3, 'Jhonson & Jhonson');
INSERT INTO Fabricante VALUES (4, 'Coleston');

-- Inserindo registros na tabela PRODUTO.

INSERT INTO Produto VALUES (10, 'Sabonete em Barra', 2);
INSERT INTO Produto VALUES (11, 'Shampoo Anticaspa', 1);
INSERT INTO Produto VALUES (12, 'Desodorante Aerosol Neutro', 2);
INSERT INTO Produto VALUES (13, 'Sabonete Liquido', 2);
INSERT INTO Produto VALUES (14, 'Protetor Solar 30', 3);
INSERT INTO Produto VALUES (15, 'Shampoo 2 em 1', 2);
INSERT INTO Produto VALUES (16, 'Desodorante Aerosol Morango', 2);
INSERT INTO Produto VALUES (17, 'Shampoo Anticaspa', 2);
INSERT INTO Produto VALUES (18, 'Protetor Solar 60', 3);
INSERT INTO Produto VALUES (19, 'Desodorante Rollon', 1);

-- Inserindo registros na tabela LOTE.

INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (100, '2028-08-05', 9.90, 500, DEFAULT, 18);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (101, '2027-05-01', 8.47, 500, DEFAULT, 10);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (102, '2028-06-02', 11.50, 750, DEFAULT, 19);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (103, '2026-02-01', 12.37, 383, DEFAULT, 18);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (104, '2027-01-01', 10.00, 400, DEFAULT, 17);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (105, '2026-04-07', 11.50, DEFAULT, DEFAULT, 15);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (106, '2023-06-08', 10.30, 320, DEFAULT, 17);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (107, '2024-10-20', 13.90, 456, DEFAULT, 12);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (108, '2026-07-20', 7.53, 750, DEFAULT, 13);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (109, '2025-05-13', 8.00, 720, DEFAULT, 11);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (110, '2027-06-05', 9.50, 860, DEFAULT, 13);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (111, '2028-03-02', 14.50, 990, DEFAULT, 14);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (112, '2028-04-05', 11.40, 430, DEFAULT, 14);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (113, '2025-06-04', 11.30, 200, DEFAULT, 12);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (114, '2027-10-06', 12.76, 380, DEFAULT, 19);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (115, '2028-11-06', 8.30, 420, DEFAULT, 17);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (116, '2027-10-20', 8.99, 361, DEFAULT, 19);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (117, '2024-11-15', 10.09, 713, DEFAULT, 11);


update Lote
set valorlote = quantidade * precounitario
where numlote >= 100

--questao1
select numlote from Lote where datavalidade between '01/01/2024' and '31/12/2024'

--questao2
select COUNT(numlote) as para_2025 from Lote where datavalidade between '01/01/2025' and '31/12/2025'

--questao3
select
p.nomeproduto as nomeproduto,
count(l.codproduto) as numero_lotes
from Lote l
join
Produto p on p.codproduto = l.codproduto
GROUP BY p.nomeproduto

--questao4
select
p.nomeproduto as nomeproduto,
count(l.codproduto) as numero_lotes
from Lote l
join
Produto p on p.codproduto = l.codproduto
where l.codproduto = 11
GROUP BY p.nomeproduto

--questao5
select
* from Lote
order by datavalidade

--questao6
select numlote, datavalidade from Lote where datavalidade between '01/02/2024' and '01/06/2026'

--questao7
select * from Lote where valorlote > (select avg(valorlote) from Lote)

--questao A
INSERT INTO Fabricante VALUES (5, 'Ancora');
INSERT INTO Produto VALUES (20, 'Sabonete de Glicerina', 5);
INSERT INTO Lote (numlote, datavalidade, precounitario, quantidade, valorlote, codproduto) VALUES (118, '2028-12-29', 3.78, 1223, DEFAULT, 20);

--questao8
update Lote
set precounitario = 3.78 - (3.78 * 0.15)
where numlote = 118

--questao9
delete from Lote where codproduto = 17
delete from Produto where nomeproduto = 'Shampoo Anticaspa' and codfabricante = 2

--questao10


--questao11


